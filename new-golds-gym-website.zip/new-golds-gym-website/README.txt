NEW GOLD'S GYM WEBSITE

Files
- index.html: complete responsive one-page website (HTML, CSS and JavaScript in one file)

How to preview
1. Extract the ZIP (if downloaded).
2. Open index.html in Chrome, Edge or Firefox.
3. An internet connection is needed for Google Fonts, Font Awesome and the remote sample photos.

Before publishing
- Replace sample Unsplash photos with real photos of this gym, with permission.
- Confirm phone number, address, opening hours and services with the gym owner.
- Confirm any membership prices before adding them. The page intentionally does not invent prices.
- Confirm that the gym is authorized to use any Gold's Gym trademarks/logos. This page currently uses a text-only design mark, not an official logo.
- The enquiry form opens WhatsApp; it does not save enquiries to a database. A backend is needed for stored enquiries or an admin panel.

To customize
- Search index.html for the phone number +917567773532 and replace it if the owner confirms a different number.
- Search for the address and opening hours to edit those details.
- Replace image URLs in the CSS and Gallery section with approved gym photos.
